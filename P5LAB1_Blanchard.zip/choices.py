def choice_menu(choice_1, choice_2):


  while True:
      user_choice = input("Choose 1 or 2: ")
      if user_choice in ['1', '2']:
          return user_choice
      else:
          print("Invalid choice. Please try again.")