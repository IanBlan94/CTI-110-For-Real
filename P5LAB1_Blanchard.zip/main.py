# CTI 110
# P5LAB1 - CYOA
# Ian Blanchard
# 10/26/23
# Feel free to fork this REPL and make changes.

# first function: main_menu().
from choices import choice_menu

def main():
  print("M5LAB1 - Choose Your Own Adventure")
  main_menu()
  print("Thanks for playing!")


def main_menu():
    print("Main Menu")
    print("You're in front of a spooky old house...")
    print("Do you:")
    print("1. Try the front door")
    print("2. Sneak around back")
    print("3. Forget it and go home")
    print("4. [Quit]")
    choice = input("Choose a number: ")
    if choice == '1':
        choice_front_door()
    elif choice == '2':
        choice_back_door()
    elif choice == '3':
        choice_go_home()
        pass
    elif choice == '4':
        print("Ok, quitting game")
        return
    else:
        print("That's not a valid choice, please try again.")
        main_menu()

# now we have the choice functions. Feel free to add more.
def choice_front_door():
    print("Try the front door.")
    print("It's locked.")
    print("Do you:")
    print("1. Check around back")
    print("2. Give up and go home")
    choice = choice_menu("Go around to the back", "Give up and go home")
    if choice == '1':
        choice_back_door()
    elif choice == '2':
        choice_go_home()
    else:
        print("You have to choose...")
        choice_front_door()

def choice_back_door():
    print("You find the back door ajar")
    print("Do you:")
    print("1. Dare enter?")
    print("2. Turn around and go home? ")
    choice = input("Choose a number: ")
    if choice == '1':
        corridor()
    elif choice == '2':
        choice_go_home()
    else:
        print("You have to choose...")
        choice_back_door()
    

def choice_go_home():
    print("You decide that your life is more important than some scary story ")
    print("and decide to go home.")

  
def corridor():
   print("You enter into the corridor, you feel a cold chill run along your spine.") 
   print("You see a staircase, one going up, one going down.")
   print("Do you:")
   print("1. Go up the stairs?")
   print("2. Go down the stairs? ")
   print("3. Go back home")
   choice = input("Choose a number: ")
   if choice == '1':
       up_stairs()
   elif choice == '2':
       down_stairs()
   elif choice == '3':
       choice_go_home()
   else:
       print("You have to choose...")
       choice_back_door()
     
def up_stairs():
  print("Once upstairs you find yourself in a long hallway.")
  print("A door is on your left and a door on your right.")
  print("Which door would you like to enter?")
  print("1. Left door")
  print("2. Right door")
  print("3. Go back to the corridor")
  choice = input("Choose a number: ")
  if choice == '1':
     left_door()
  elif choice == '2':
     right_door()
  elif choice == '3':
    corridor() 
  else:
     print("You have to choose...")
     up_stairs()
    
def left_door():
  print("You are hit in the head by a falling axe")
  print("You Died")
  
def right_door():
  print("You enter the door to find a woman sitting on the edge of the bed.")
  print("She doesnt seem to notice you")
  print("Do you:")
  print("1. Get her attention")
  print("2. Go back to the corridor")
  choice = input("Choose a number: ")
  if choice == '1':
     print("Her head falls off when you tap her shoulder")
     print("Your body feels cold and you cant move")
     print("The headless woman attacks you, slicing your throat")
     print("You died")
  elif choice == '2':
     corridor()
  else:
     print("You have to choose...")
     right_door()
    
def down_stairs():
  print("You go down the stairs, with every step your nerves spark with electricity")
  print("At the bottom of the steps you see two trap doors ")
  print("Do you")
  print("1. Enter the first trap door")
  print("2. Enter the second trap door")
  print("3. Go back to the corridor")
  choice = input("Choose a number: ")
  if choice == '1':
     print("You fall down the trap door, breaking your legs when you land")
     print("As you lay there, helpless, rats start to swarm you")
     print("The rats eat you alive")
     print("You died")
  elif choice == '2':
    emerald_room()
  elif choice == '3':
    corridor() 
  else:
     print("You have to choose...")
     down_stairs()
    
def emerald_room():
  print("You find a room filled with gems and gold!")
  print("Do you:")
  print("1. Take as much as your pockets can hold")
  print("2. Leave it alone")
  choice = input("Choose a number: ")
  if choice == '1':
     print("As you stuff your pockets, a skelton jumps out and grabs you")
     print("You try to break free, but the skeletons grip is too strong")
     print("With one mighty swing the skeleton decapitates you")
     print("You died")
  elif choice == '2':
     print("You leave the haunted mansion empty handed, but alive")
  else:
     print("You have to choose...")
     emerald_room()
#start the program
main()
